const validateEnv = require('./envutils').validateEnv;
let url;
// account network config
const host = validateEnv('PRIVATE_NETWORK_HOST');
const port = validateEnv('PRIVATE_NETWORK_RPCPORT');
url = 'http://' + host + ':' + port;

module.exports = {
    url
};
